# PTT · Canal de taxis (prototipo independiente)

Primera versión centrada en móvil para probar la experiencia push-to-talk.

## Funcional ahora
- Registro local de nombre, número de taxi y teléfono (se guarda en `localStorage`).
- Canal visual «Todos los taxis».
- Botón PTT grande: mantener pulsado cambia el estado y muestra en grande el número del taxi que habla.
- Lista básica de participantes de ejemplo.
- El navegador solicita permiso de micrófono únicamente al iniciar la primera transmisión (si se concede, el prototipo abre y detiene el micrófono; no envía audio).
- Interfaz responsive y usable con táctil.

## Pendiente para comunicación real
Este prototipo **no conecta teléfonos ni transmite audio**. El estado PTT es local y los participantes son datos de ejemplo. Para producción hacen falta backend, autenticación, presencia/señalización y una capa de audio en tiempo real con WebRTC (STUN/TURN y posiblemente SFU/media server) o un servicio de voz equivalente.

Abrir `index.html` desde un servidor local/HTTPS (necesario para que el navegador permita micrófono). Ejemplo: `python3 -m http.server 8080` dentro de esta carpeta.
