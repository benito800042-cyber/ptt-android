# PTT Android · Canal de taxis

APK independiente del prototipo PTT local. Está hecha para móvil con una interfaz WebView que empaqueta `index.html`, `styles.css` y `app.js` dentro de la aplicación.

## Qué incluye
- Identidad local editable: nombre, teléfono y número de taxi; se conserva en el almacenamiento local del dispositivo.
- Botón circular PTT con pulsación mantenida y número del taxi que habla simulado en pantalla.
- El permiso de micrófono se solicita únicamente al pulsar PTT. El micrófono se abre y detiene como demostración, sin enviar audio.
- Sin servidor, cuentas ni conexión entre teléfonos: participantes y estado son locales/de ejemplo.

> **Importante:** esta APK es un prototipo local. Todavía no hay voz real entre teléfonos. Para producción se necesitarían backend, autenticación, señalización y WebRTC/STUN/TURN o un servicio de voz.

## Compilar
En GitHub Actions: ejecutar manualmente el workflow **Build APK** o crear una etiqueta `v*`. El workflow compila y, para etiquetas, publica el APK debug en una release pública.
