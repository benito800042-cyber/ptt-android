# PTT signaling backend

Node.js 22+ WebSocket signaling server. The demo deployment uses `PTT_DEMO_MODE=true`, which accepts `hello` messages with `mode: "demo"` and no token, caps the public channel at 8 clients, and exposes only name/taxi presence. This is for testing only and is not private.

For production set `PTT_DEMO_MODE=false` and provide `PTT_SHARED_TOKEN` (or replace it with per-user authentication, authorization and rate limiting). Keep the service behind TLS/WSS. The first message must contain `hello` and `{name,taxi,phone}`; demo clients additionally send `mode:"demo"`.
