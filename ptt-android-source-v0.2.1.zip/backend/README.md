# PTT signaling backend (v0.2)

Servidor mínimo de señalización/presencia. **No procesa ni almacena audio**: WebRTC transporta el audio directamente entre móviles. El servidor mantiene presencia en memoria y un lease de un único hablante para `Todos los taxis`.

## Despliegue

Requiere Node.js 18+ y un endpoint HTTPS con WebSocket (`wss://`). En un servidor:

```sh
npm install
PTT_SHARED_TOKEN='un-secreto-largo-y-aleatorio' PORT=8080 npm start
```

Publicar `/` (WebSocket) mediante proxy TLS y conservar `/healthz` para comprobación. El cliente se configura en ⚙ con la URL `wss://...` y el mismo token. No desplegar sin TLS. El token compartido es autenticación básica de MVP; para producción sustituirlo por cuentas/tokens rotatorios y rate limiting.

## Protocolo

El primer mensaje debe ser `hello` con `token` y `{name,taxi,phone}`. El servidor devuelve `welcome` y emite `presence`; `claim` obtiene el canal si está libre, `release` lo libera. `offer`, `answer` e `ice` se reenvían únicamente entre el hablante y cada participante. Perfiles públicos contienen solo nombre y taxi; el teléfono se valida pero no se difunde.

El cliente usa STUN público como ayuda para descubrir rutas; STUN no sustituye TURN y algunas redes móviles/firewalls requerirán configurar TURN (y añadir sus credenciales en el cliente). No se incluyen credenciales ni un despliegue en este repositorio. Sin una URL WSS pública, dos APK no pueden conectarse.
