# Render deployment (one-time)

Create a **Web Service** from `benito800042-cyber/ptt-android` with root directory **`backend`** (do not prepend `PTT-Android/`; that is only the local extracted folder name). Use runtime Node, build `npm install --omit=dev`, start `npm start`, and health check `/healthz`. Render provides HTTPS; the client endpoint must use the corresponding `wss://<service>.onrender.com` URL.

If using the Blueprint, select **New > Blueprint Instance** and point it at the repository root; Render will read the root `render.yaml`, whose `rootDir: backend` is relative to the repository root. If creating the service manually, set the same root directory and commands in the service settings.

Add environment variable `PTT_SHARED_TOKEN` using Render's **Generate value** (never commit or paste it into source). Copy it only into the two test phones' local Settings fields. Do not put the token in a public APK or URL.

After deployment:

```sh
curl -fsS https://<service>.onrender.com/healthz
# expected: {"ok":true,"clients":0,"speaker":false}
```

A WebSocket hello uses the same token. Two-device audio is not verified until two physical Android devices connect and one transmits while the other receives.
