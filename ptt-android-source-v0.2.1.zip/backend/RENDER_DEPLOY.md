# Deploy on Render

Create a Web Service from `benito800042-cyber/ptt-android` with root directory `backend`, build `npm install --omit=dev`, start `npm start`, and health check `/healthz`.

The current test deployment enables `PTT_DEMO_MODE=true`: the app joins `wss://ptt-android.onrender.com` without José copying a secret. This is an explicitly public demo channel capped at 8 concurrent clients. It is not private; do not use it for real conversations.

`PTT_SHARED_TOKEN` is intentionally retained and is not deleted or changed. For production, set `PTT_DEMO_MODE=false` and use a long random `PTT_SHARED_TOKEN` (or, preferably, per-user authentication, authorization and rate limiting). Never put production secrets in the APK or URL.
