# PTT · Canal de taxis

Cliente web empaquetado en la APK independiente. La identidad (nombre, teléfono y taxi) se conserva en localStorage. El teléfono se envía solo al backend para validar el perfil y no aparece en presencia pública.

Sin servidor WSS configurado funciona como demo local y no transmite audio. Con `backend/server.js` desplegado detrás de TLS, el cliente usa presencia, control exclusivo del canal y WebRTC peer-to-peer para el audio. La conectividad móvil real requiere probar STUN/TURN en dos redes distintas; esta versión no incluye TURN ni afirma audio verificado.
