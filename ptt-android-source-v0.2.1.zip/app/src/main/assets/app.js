const $=s=>document.querySelector(s);
const defaults={name:'José Pérez',taxi:'13',phone:'600 000 000'};
const DEFAULT_ENDPOINT='wss://ptt-android.onrender.com';
function readLocal(key,fallback){try{return JSON.parse(localStorage.getItem(key)||'null')||fallback}catch(e){return fallback}}
let profile=readLocal('ptt-profile',defaults);
// The default is applied only on first launch; an explicitly blank server stays blank.
const savedConfig=readLocal('ptt-config',null);
let cfg=savedConfig||{endpoint:DEFAULT_ENDPOINT};
// The public demo never needs a token; discard any legacy token from the UI/config.
if (!cfg.endpoint) cfg.endpoint=DEFAULT_ENDPOINT;
delete cfg.token;
if(!savedConfig)localStorage.setItem('ptt-config',JSON.stringify(cfg));
let socket=null, selfId=null, speaker=null, stream=null, speaking=false, pressed=false, participants=null;
const peers=new Map();
const seed=[{id:'demo-7',name:'María',taxi:'7',online:true},{id:'demo-4',name:'Antonio',taxi:'4',online:true}];
function initials(n){return n.split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase()}
function setConnection(text,online=false){$('#connection').textContent=text;$('#connection').className=online?'live-pill online':'live-pill'}
function render(list){if(list)participants=list;$('#profileName').textContent=profile.name;$('#profileTaxi').textContent=profile.taxi;$('#profilePhone').textContent=profile.phone;$('#avatar').textContent=initials(profile.name);$('#configSummary').textContent=cfg.endpoint?`Demo público · ${cfg.endpoint}`:'Servidor: modo local (sin WSS)';let all=participants||[ {id:'self',...profile,online:true},...seed ];$('#participantList').innerHTML=all.map(p=>`<div class="participant"><div class="p-avatar">${initials(p.name)}</div><div class="p-main"><div class="p-name">${p.name}${p.id===selfId?' (tú)':''}</div><div class="p-meta">Taxi ${p.taxi}</div></div><div class="p-state">● ${speaker&&p.id===speaker.id?'HABLANDO':'En línea'}</div></div>`).join('');$('#count').textContent=`${all.length} conectados`}
function openProfile(){$('#nameInput').value=profile.name;$('#taxiInput').value=profile.taxi;$('#phoneInput').value=profile.phone;$('#endpointInput').value=cfg.endpoint;$('#profileDialog').showModal()}
$('#settingsBtn').onclick=openProfile;
$('#profileForm').addEventListener('submit',e=>{e.preventDefault();profile={name:$('#nameInput').value.trim(),taxi:$('#taxiInput').value.trim(),phone:$('#phoneInput').value.trim()};cfg={endpoint:$('#endpointInput').value.trim()||DEFAULT_ENDPOINT};localStorage.setItem('ptt-profile',JSON.stringify(profile));localStorage.setItem('ptt-config',JSON.stringify(cfg));render();$('#profileDialog').close();connect()});
function wsSend(m){if(socket&&socket.readyState===WebSocket.OPEN)socket.send(JSON.stringify(m))}
function connect(){if(socket){socket.close();socket=null} if(!cfg.endpoint){setConnection('LOCAL');render();return} try{socket=new WebSocket(cfg.endpoint)}catch(e){setConnection('ERROR DE CONEXIÓN');return} socket.onopen=()=>{setConnection('CONECTADO',true);wsSend({type:'hello',mode:'demo',profile})};socket.onclose=()=>{if(!speaking) setConnection('SIN CONEXIÓN');selfId=null;speaker=null;render()};socket.onerror=()=>setConnection('ERROR DE CONEXIÓN');socket.onmessage=e=>onMessage(JSON.parse(e.data))}
function onMessage(m){if(m.type==='welcome'){selfId=m.id;speaker=m.speaker;syncPeers(m.participants);render(m.participants)}if(m.type==='presence'){speaker=m.speaker;syncPeers(m.participants);render(m.participants)}if(m.type==='speaker'){speaker=m.speaker;render();$('#speakerNumber').textContent=speaker?speaker.taxi:'—';$('#speakerCaption').textContent=speaker?`Taxi ${speaker.taxi} está hablando`:'Mantén pulsado para transmitir'}if(m.type==='claim_ack'){if(m.ok)claimAck();else{pressed=false;$('#statusLabel').textContent='CANAL OCUPADO'}}if(m.type==='signal')handleSignal(m)}
function syncPeers(list){if(!list)return;const ids=new Set(list.map(p=>p.id).filter(id=>id&&id!==selfId));for(const id of ids)ensurePeer(id);for(const [id,pc] of peers)if(!ids.has(id)){pc.close();peers.delete(id)}}
async function startTalk(){if(speaking|| (speaker&&speaker.id!==selfId))return; pressed=true; if(!cfg.endpoint){await localMic();return} wsSend({type:'claim'});}
async function localMic(){try{stream=stream||await navigator.mediaDevices.getUserMedia({audio:true});speaking=true;speaker={id:selfId||'self',name:profile.name,taxi:profile.taxi};activate();}catch(e){pressed=false;$('#statusLabel').textContent='MICRÓFONO NO ACTIVADO';$('#speakerCaption').textContent='Permiso necesario para hablar'}}
async function activate(){speaker={id:selfId||'self',name:profile.name,taxi:profile.taxi};$('#speaker').classList.add('talking');$('#ptt').classList.add('active');$('#statusLabel').textContent=cfg.endpoint?'TRANSMITIENDO':'TRANSMITIENDO · SOLO LOCAL';$('#speakerNumber').textContent=profile.taxi;$('#speakerCaption').textContent=`Taxi ${profile.taxi} está hablando`;render() ;if(cfg.endpoint){for(const p of [...document.querySelectorAll('.participant')]){};}}
async function claimAck(){await localMic(); if(!stream)return; const list=[...peers.keys()]; for(const id of list) await makeOffer(id)}
function stopTalk(){pressed=false;if(!speaking){if(cfg.endpoint)wsSend({type:'release'});return}speaking=false;if(cfg.endpoint)wsSend({type:'release'});if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}peers.forEach(p=>p.close());peers.clear();speaker=null;$('#speaker').classList.remove('talking');$('#ptt').classList.remove('active');$('#statusLabel').textContent='LISTO PARA HABLAR';$('#speakerNumber').textContent='—';$('#speakerCaption').textContent='Mantén pulsado para transmitir';render()}
function ensurePeer(id){if(peers.has(id))return peers.get(id);const pc=new RTCPeerConnection({iceServers:[{urls:'stun:stun.l.google.com:19302'}]});peers.set(id,pc);pc.onicecandidate=e=>{if(e.candidate)wsSend({type:'signal',to:id,signalType:'ice',data:e.candidate})};pc.ontrack=e=>{const a=new Audio();a.autoplay=true;a.srcObject=e.streams[0];a.play().catch(()=>{})};return pc}
async function makeOffer(id){const pc=ensurePeer(id);stream.getTracks().forEach(t=>pc.addTrack(t,stream));const o=await pc.createOffer();await pc.setLocalDescription(o);wsSend({type:'signal',to:id,signalType:'offer',data:o})}
async function handleSignal(m){const pc=ensurePeer(m.from);if(m.signalType==='offer'){await pc.setRemoteDescription(m.data);const a=await pc.createAnswer();await pc.setLocalDescription(a);wsSend({type:'signal',to:m.from,signalType:'answer',data:a})}else if(m.signalType==='answer')await pc.setRemoteDescription(m.data);else if(m.signalType==='ice')try{await pc.addIceCandidate(m.data)}catch(e){} }
$('#ptt').addEventListener('pointerdown',e=>{e.preventDefault();startTalk()});['pointerup','pointercancel','pointerleave'].forEach(x=>$('#ptt').addEventListener(x,stopTalk));
$('#helpBtn').onclick=()=>$('#helpDialog').showModal();$('#closeHelp').onclick=()=>$('#helpDialog').close();render();connect();
